"""The SAMANVAY API.

Two audiences, one service.

**Machines in other departments.** The whole point of harmonisation is that the water
board, the planning authority and the revenue department stop maintaining divergent copies
of the same geometry. That requires a standards-compliant, versioned, subscribable feed —
so the feature endpoints implement **OGC API - Features (Part 1: Core)**, which is the
current OGC standard and what the National Geospatial Policy expects of a government
geospatial service. A department can point QGIS, ArcGIS or a plain HTTP client at it
without any SAMANVAY-specific code.

**People in this department.** The console needs things no OGC standard defines: the
adjudication queue, confidence explanations, lineage verification, the run record. Those
live under ``/api/`` and are explicitly non-standard.

Two design decisions are worth stating because they are unusual:

*Personal data is not served by the feature API at all.* Owner names are reachable only
through a purpose-bound endpoint that logs the access. A cadastral API that returns
owner names is a bulk personal-data export with a map on it.

*Every feature carries its confidence and its lineage head.* A consumer that cannot see how
much to trust a boundary will treat all boundaries alike, which defeats the entire exercise.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

from fastapi import Depends, FastAPI, HTTPException, Query, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, JSONResponse

from ..core.ledger import ProvenanceLedger
from ..attributes.canonical import PARCEL_SCHEMA, redact_pii

API_VERSION = "1.0.0"
TITLE = "SAMANVAY — harmonised urban land records"


# --------------------------------------------------------------------------------------
# store
# --------------------------------------------------------------------------------------


@dataclass
class FeatureStore:
    """Serves the pipeline's published GeoJSON.

    A file-backed store is used deliberately for the reference deployment: it makes the API
    runnable straight after a pipeline run with no database, which matters for a district
    office evaluating the system. ``PostgisStore`` below is the production path and
    implements the same interface.
    """

    out_dir: str
    _collections: dict[str, list[dict[str, Any]]] | None = None
    _ledger: ProvenanceLedger | None = None

    FILES = {
        "parcels": "harmonised_parcels.geojson",
        "buildings": "harmonised_buildings.geojson",
        "adjudication": "adjudication_queue.geojson",
    }

    def load(self) -> None:
        self._collections = {}
        for name, fn in self.FILES.items():
            path = os.path.join(self.out_dir, fn)
            if not os.path.exists(path):
                self._collections[name] = []
                continue
            with open(path, encoding="utf-8") as fh:
                data = json.load(fh)
            self._collections[name] = data.get("features", [])
        lpath = os.path.join(self.out_dir, "ledger.jsonl")
        self._ledger = ProvenanceLedger(lpath) if os.path.exists(lpath) else ProvenanceLedger()

    @property
    def collections(self) -> dict[str, list[dict[str, Any]]]:
        if self._collections is None:
            self.load()
        return self._collections  # type: ignore[return-value]

    @property
    def ledger(self) -> ProvenanceLedger:
        if self._ledger is None:
            self.load()
        return self._ledger  # type: ignore[return-value]

    def metrics(self) -> dict[str, Any]:
        path = os.path.join(self.out_dir, "metrics.json")
        if not os.path.exists(path):
            return {}
        with open(path, encoding="utf-8") as fh:
            return json.load(fh)

    def queue(self) -> list[dict[str, Any]]:
        path = os.path.join(self.out_dir, "adjudication_queue.json")
        if not os.path.exists(path):
            return []
        with open(path, encoding="utf-8") as fh:
            return json.load(fh)

    def changes(self) -> list[dict[str, Any]]:
        path = os.path.join(self.out_dir, "changes.json")
        if not os.path.exists(path):
            return []
        with open(path, encoding="utf-8") as fh:
            return json.load(fh)


def create_app(out_dir: str = "out/chennai") -> FastAPI:
    app = FastAPI(
        title=TITLE,
        version=API_VERSION,
        description=__doc__,
        docs_url="/api/docs",
        openapi_url="/api/openapi.json",
    )
    app.add_middleware(
        CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"],
    )
    store = FeatureStore(out_dir=out_dir)
    app.state.store = store

    # ==================================================================================
    # OGC API - Features
    # ==================================================================================

    @app.get("/", tags=["ogc"])
    def landing(request: Request) -> dict[str, Any]:
        base = str(request.base_url).rstrip("/")
        return {
            "title": TITLE,
            "description": (
                "Harmonised cadastral parcels and building footprints for the "
                "demonstration area of interest, integrated from multiple government "
                "sources with per-feature confidence and verifiable lineage."
            ),
            "links": [
                {"rel": "self", "type": "application/json", "href": f"{base}/"},
                {"rel": "conformance", "type": "application/json",
                 "href": f"{base}/conformance"},
                {"rel": "data", "type": "application/json", "href": f"{base}/collections"},
                {"rel": "service-desc", "type": "application/vnd.oai.openapi+json;version=3.0",
                 "href": f"{base}/api/openapi.json"},
                {"rel": "service-doc", "type": "text/html", "href": f"{base}/api/docs"},
            ],
        }

    @app.get("/conformance", tags=["ogc"])
    def conformance() -> dict[str, Any]:
        return {"conformsTo": [
            "http://www.opengis.net/spec/ogcapi-features-1/1.0/conf/core",
            "http://www.opengis.net/spec/ogcapi-features-1/1.0/conf/oas30",
            "http://www.opengis.net/spec/ogcapi-features-1/1.0/conf/geojson",
            "http://www.opengis.net/spec/ogcapi-features-3/1.0/conf/filter",
        ]}

    @app.get("/collections", tags=["ogc"])
    def collections(request: Request) -> dict[str, Any]:
        base = str(request.base_url).rstrip("/")
        descriptions = {
            "parcels": "Harmonised cadastral parcels with ULPIN and confidence.",
            "buildings": "Harmonised building footprints with parcel linkage.",
            "adjudication": "Open conflicts awaiting human decision, as a map layer.",
        }
        return {
            "collections": [
                {
                    "id": name,
                    "title": name.title(),
                    "description": descriptions.get(name, ""),
                    "itemType": "feature",
                    "crs": ["http://www.opengis.net/def/crs/OGC/1.3/CRS84"],
                    "extent": _extent(feats),
                    "itemCount": len(feats),
                    "links": [
                        {"rel": "items", "type": "application/geo+json",
                         "href": f"{base}/collections/{name}/items"},
                    ],
                }
                for name, feats in store.collections.items()
            ],
            "links": [{"rel": "self", "href": f"{base}/collections"}],
        }

    @app.get("/collections/{collection_id}/items", tags=["ogc"])
    def items(
        collection_id: str,
        request: Request,
        bbox: str | None = Query(None, description="minx,miny,maxx,maxy in CRS84"),
        limit: int = Query(1000, ge=1, le=100000),
        offset: int = Query(0, ge=0),
        min_confidence: float = Query(0.0, ge=0.0, le=1.0),
        grade: str | None = Query(None, description="Filter by confidence grade A-E"),
        ward: str | None = None,
        ulpin: str | None = None,
        survey_number: str | None = None,
        change_type: str | None = None,
    ) -> JSONResponse:
        feats = store.collections.get(collection_id)
        if feats is None:
            raise HTTPException(404, f"unknown collection {collection_id!r}")

        box = _parse_bbox(bbox)
        out: list[dict[str, Any]] = []
        for f in feats:
            p = f.get("properties", {})
            if min_confidence and float(p.get("confidence") or 0) < min_confidence:
                continue
            if grade and p.get("confidence_grade") != grade.upper():
                continue
            if ward and str(p.get("ward") or "") != str(ward):
                continue
            if ulpin and p.get("ulpin") != ulpin:
                continue
            if survey_number and str(p.get("survey_number") or "") != str(survey_number):
                continue
            if change_type and p.get("change_type") != change_type:
                continue
            if box and not _bbox_hit(_geom_bounds(f.get("geometry")), box):
                continue
            out.append({**f, "properties": redact_pii(p, PARCEL_SCHEMA)})

        total = len(out)
        page = out[offset: offset + limit]
        base = str(request.base_url).rstrip("/")
        links = [{"rel": "self", "href": str(request.url)}]
        if offset + limit < total:
            links.append({
                "rel": "next",
                "href": f"{base}/collections/{collection_id}/items"
                        f"?limit={limit}&offset={offset + limit}",
            })
        return JSONResponse({
            "type": "FeatureCollection",
            "features": page,
            "numberMatched": total,
            "numberReturned": len(page),
            "timeStamp": datetime.now(timezone.utc).isoformat(),
            "links": links,
        }, media_type="application/geo+json")

    @app.get("/collections/{collection_id}/items/{feature_id}", tags=["ogc"])
    def item(collection_id: str, feature_id: str) -> JSONResponse:
        feats = store.collections.get(collection_id)
        if feats is None:
            raise HTTPException(404, f"unknown collection {collection_id!r}")
        for f in feats:
            p = f.get("properties", {})
            if p.get("entity_id") == feature_id or p.get("ulpin") == feature_id:
                return JSONResponse({**f, "properties": redact_pii(p, PARCEL_SCHEMA)},
                                    media_type="application/geo+json")
        raise HTTPException(404, f"feature {feature_id!r} not found in {collection_id!r}")

    # ==================================================================================
    # platform API
    # ==================================================================================

    @app.get("/api/run", tags=["platform"])
    def run_record() -> dict[str, Any]:
        m = store.metrics()
        if not m:
            raise HTTPException(404, "no pipeline run has been published to this instance")
        return m

    @app.get("/api/quality", tags=["platform"])
    def quality() -> dict[str, Any]:
        """Aggregate quality, and the same figures broken down by ward."""
        parcels = store.collections.get("parcels", [])
        buildings = store.collections.get("buildings", [])
        by_ward: dict[str, dict[str, Any]] = {}
        for f in parcels:
            p = f["properties"]
            w = str(p.get("ward") or "unknown")
            e = by_ward.setdefault(w, {"parcels": 0, "confidence_sum": 0.0,
                                       "publishable": 0, "needs_check": 0,
                                       "conflicts": 0, "area_m2": 0.0})
            e["parcels"] += 1
            e["confidence_sum"] += float(p.get("confidence") or 0)
            g = p.get("confidence_grade")
            if g in ("A", "B"):
                e["publishable"] += 1
            elif g in ("D", "E"):
                e["needs_check"] += 1
            e["conflicts"] += int(p.get("conflicts") or 0)
            e["area_m2"] += float(p.get("computed_extent_m2") or 0)
        for w, e in by_ward.items():
            e["mean_confidence"] = round(e.pop("confidence_sum") / max(e["parcels"], 1), 4)
        return {
            "parcels": len(parcels),
            "buildings": len(buildings),
            "grades": _grade_counts(parcels + buildings),
            "mean_confidence": round(
                sum(float(f["properties"].get("confidence") or 0)
                    for f in parcels + buildings) / max(len(parcels) + len(buildings), 1), 4),
            "by_ward": dict(sorted(by_ward.items(),
                                   key=lambda kv: -kv[1]["parcels"])[:60]),
        }

    @app.get("/api/adjudication", tags=["platform"])
    def adjudication(limit: int = Query(50, ge=1, le=500),
                     batch: str | None = None) -> dict[str, Any]:
        cases = store.queue()
        if batch:
            cases = [c for c in cases if c.get("batch") == batch]
        return {"total": len(cases), "cases": cases[:limit]}

    @app.get("/api/changes", tags=["platform"])
    def changes(change_type: str | None = None, actionable: bool | None = None,
                limit: int = Query(200, ge=1, le=5000)) -> dict[str, Any]:
        recs = store.changes()
        if change_type:
            recs = [r for r in recs if r.get("change_type") == change_type]
        if actionable is not None:
            recs = [r for r in recs if bool(r.get("is_actionable")) is actionable]
        counts: dict[str, int] = {}
        for r in store.changes():
            counts[r["change_type"]] = counts.get(r["change_type"], 0) + 1
        return {"total": len(recs), "counts": counts, "records": recs[:limit]}

    @app.get("/api/lineage/{entity_id}", tags=["platform"])
    def lineage(entity_id: str) -> dict[str, Any]:
        entries = store.ledger.history(entity_id)
        ok, broken, msg = store.ledger.verify()
        return {
            "entity_id": entity_id,
            "entries": [
                {"index": e.index, "at": e.timestamp, "operation": e.operation,
                 "actor": e.actor, "payload": e.payload, "hash": e.entry_hash}
                for e in entries
            ],
            "chain_verified": ok,
            "chain_message": msg,
            "merkle_root": store.ledger.merkle_root(),
        }

    @app.get("/api/verify", tags=["platform"])
    def verify() -> dict[str, Any]:
        ok, broken, msg = store.ledger.verify()
        return {
            "verified": ok, "broken_at": broken, "message": msg,
            "entries": len(store.ledger),
            "merkle_root": store.ledger.merkle_root(),
            "how_to_check_independently": (
                "Recompute sha256 over index|timestamp|entity_id|operation|actor|"
                "canonical(payload)|prev_hash for each line of ledger.jsonl and confirm it "
                "equals that line's entry_hash and the next line's prev_hash."
            ),
        }

    @app.get("/api/schema", tags=["platform"])
    def schema() -> dict[str, Any]:
        return {
            "canonical_fields": [
                {"name": f.name, "kind": f.kind.value, "type": f.dtype,
                 "required": f.required, "pii": f.pii, "unit": f.unit,
                 "domain": list(f.domain) if f.domain else None,
                 "aliases": list(f.aliases), "description": f.description}
                for f in PARCEL_SCHEMA.values()
            ]
        }

    @app.get("/api/owner/{ulpin}", tags=["platform"])
    def owner(ulpin: str, purpose: str = Query(..., min_length=8),
              requester: str = Query(..., min_length=3)) -> dict[str, Any]:
        """Purpose-bound access to owner data.

        Returns nothing useful in this reference deployment, on purpose: the demonstration
        corpus contains no owner names, and the endpoint exists to show where the DPDP
        boundary sits and that access is logged rather than open. In production this is the
        only path to personal data and it writes an access record to the ledger before
        returning.
        """
        store.ledger.append(ulpin, "pii_access",
                            {"requester": requester, "purpose": purpose},
                            actor=f"user/{requester}")
        return {
            "ulpin": ulpin,
            "owner_name": None,
            "note": ("Access recorded in the provenance ledger. No owner attribute exists "
                     "in the open demonstration corpus."),
        }

    @app.get("/health", tags=["platform"])
    def health() -> dict[str, Any]:
        return {"status": "ok", "version": API_VERSION,
                "collections": {k: len(v) for k, v in store.collections.items()}}

    @app.get("/map", response_class=HTMLResponse, include_in_schema=False)
    def console() -> str:
        path = os.path.join(os.path.dirname(__file__), "..", "..", "..",
                            "frontend", "index.html")
        path = os.path.abspath(path)
        if os.path.exists(path):
            with open(path, encoding="utf-8") as fh:
                return fh.read()
        return "<h1>Console not built</h1><p>See frontend/index.html</p>"

    return app


# --------------------------------------------------------------------------------------
# helpers
# --------------------------------------------------------------------------------------


def _parse_bbox(s: str | None) -> tuple[float, float, float, float] | None:
    if not s:
        return None
    parts = [float(v) for v in s.split(",")]
    if len(parts) != 4:
        raise HTTPException(400, "bbox must be minx,miny,maxx,maxy")
    return parts[0], parts[1], parts[2], parts[3]


def _geom_bounds(geom: dict[str, Any] | None) -> tuple[float, float, float, float]:
    xs: list[float] = []
    ys: list[float] = []

    def walk(c: Any) -> None:
        if isinstance(c, list):
            if c and isinstance(c[0], (int, float)):
                xs.append(float(c[0]))
                ys.append(float(c[1]))
            else:
                for x in c:
                    walk(x)

    if geom:
        walk(geom.get("coordinates", []))
    if not xs:
        return (0.0, 0.0, 0.0, 0.0)
    return min(xs), min(ys), max(xs), max(ys)


def _bbox_hit(b: tuple[float, float, float, float],
              box: tuple[float, float, float, float]) -> bool:
    return not (b[2] < box[0] or b[0] > box[2] or b[3] < box[1] or b[1] > box[3])


def _extent(feats: list[dict[str, Any]]) -> dict[str, Any]:
    if not feats:
        return {"spatial": {"bbox": [[0, 0, 0, 0]], "crs":
                            "http://www.opengis.net/def/crs/OGC/1.3/CRS84"}}
    b = [_geom_bounds(f.get("geometry")) for f in feats]
    return {"spatial": {
        "bbox": [[min(x[0] for x in b), min(x[1] for x in b),
                  max(x[2] for x in b), max(x[3] for x in b)]],
        "crs": "http://www.opengis.net/def/crs/OGC/1.3/CRS84",
    }}


def _grade_counts(feats: list[dict[str, Any]]) -> dict[str, int]:
    out: dict[str, int] = {}
    for f in feats:
        g = f["properties"].get("confidence_grade")
        if g:
            out[g] = out.get(g, 0) + 1
    return dict(sorted(out.items()))


app = create_app(os.environ.get("SAMANVAY_OUT", "out/chennai"))
